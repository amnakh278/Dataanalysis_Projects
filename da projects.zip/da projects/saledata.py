import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
df = pd.read_csv("sales_data.csv")

# Clean and inspect data
print(df.info())
df['Date'] = pd.to_datetime(df['Date'])

# Summary statistics
print(df.describe())

# Monthly revenue trends
df['Month'] = df['Date'].dt.to_period('M').astype(str)
monthly_revenue = df.groupby('Month')['Revenue'].sum()
monthly_revenue.plot(kind='line', title='Monthly Revenue')

# Top-selling products
top_products = df.groupby('Product')['Revenue'].sum().sort_values(ascending=False).head(5)
top_products.plot(kind='bar', title='Top 5 Products by Revenue')

# Category distribution
sns.countplot(data=df, x='Category')
plt.title("Product Category Distribution")
plt.show()
